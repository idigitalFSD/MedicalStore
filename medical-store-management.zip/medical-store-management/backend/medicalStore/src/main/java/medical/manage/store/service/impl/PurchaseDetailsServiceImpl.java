package medical.manage.store.service.impl;

public class PurchaseDetailsServiceImpl {

}
