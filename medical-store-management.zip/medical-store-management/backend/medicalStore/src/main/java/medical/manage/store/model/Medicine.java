package medical.manage.store.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity(name = "medicine")
@ApiModel(description="This is Medicine model to create a table that keeps a record of names of all medicines in database.")
public class Medicine {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@ApiModelProperty(notes = "The Id value of medicine")
	@Column(name = "medicine_id")
	private int medicineId;

	@ApiModelProperty(notes = "The name of medicine")
	@Column(name = "medicine_name")
	private String medicineName;

	
	public Medicine() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Parameterized constructor
	public Medicine(String medicineName) {
		super();
		this.medicineName = medicineName;
	}

	// Getters and Setters
	public int getMedicineId() {
		return medicineId;
	}

	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	// toString()
	@Override
	public String toString() {
		return "Medicine [medicineId=" + medicineId + ", medicineName=" + medicineName + "]";
	}

}
