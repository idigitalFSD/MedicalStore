package medical.manage.store.controller;

public class PurchaseDetailsController {

}
