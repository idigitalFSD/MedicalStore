package medical.manage.store.swagger;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

}
	
