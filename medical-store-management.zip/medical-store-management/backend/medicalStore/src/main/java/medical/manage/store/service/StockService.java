package medical.manage.store.service;

import java.util.List;

import javax.validation.Valid;

import medical.manage.store.model.Stock;

public interface StockService {

	/**
	 * Get Report method
	 * 
	 * @return Report
	 */
	public List<Stock> getReport();

	public Stock addStock(@Valid Stock stock);
}
